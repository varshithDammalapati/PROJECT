# Hospital-Management-Using-Servlets
Web application for Hospital management developed on JAVA Servlets, Tomcat server abd MySQL.
